// const ApiKey = "5c305193dbe74ced987bb1e0ff36b1a0";
const baseUrl = "https://api.covid19api.com/";
const world = `${baseUrl}summary`;
const country = `${baseUrl}summary`;

const contents = document.querySelector("#content-list");
const title = document.querySelector(".card-title");
const fetchHeader = {
    method: 'GET',
    redirect: 'follow'
};
// Mengambil data list team
function getListCovid() {
    title.innerHTML = "Data Covid 19";
    fetch(world, fetchHeader)
        .then(response => response.json())
        .then(resJson => {
            console.log(resJson);
            console.log(resJson.Global.TotalDeaths);
            contents.innerHTML = '<ul class="collection">' + `<li class="collection-item avatar">
            <span class="title">DATA COVID 19</span>
            <p>KASUS BARU TERKONFIRMASI : ${resJson.Global.NewConfirmed}</p>
            <p>KASUS BARU MENINGGAL : ${resJson.Global.NewDeaths}</p>
            <p>SEMBUH : ${resJson.Global.NewRecovered}</p>
            </li>` + `<li class="collection-item avatar">
            <span class="title">DATA COVID 19</span>
            <p>KASUS BARU TERKONFIRMASI : ${resJson.Global.TotalConfirmed}</p>
            <p>KASUS BARU MENINGGAL : ${resJson.Global.TotalDeaths}</p>
            <p>SEMBUH : ${resJson.Global.TotalRecovered}</p>
            </li>` + '</ul>'
        }).catch(err => {
            console.error(err);
        })
}
//Mengambil data Country
function getListCountry() {
    title.innerHTML = "Data covid masing masing negara";
    fetch(country, fetchHeader)
        .then(response => response.json())
        .then(resJson => {
            console.log(resJson.Countries);
            let count = "";
            let i = 0;
            resJson.Countries.forEach(element => {
                count += `
                <tr>
                    <td>${i+1}</td>
                    <td>${resJson.Countries[i].Country}</td>
                    <td>${resJson.Countries[i].Date}</td>
                    <td>${resJson.Countries[i].TotalConfirmed}</td>
                    <td>${resJson.Countries[i].TotalDeaths}</td>
                    <td>${resJson.Countries[i].TotalRecovered}</td>
                </tr>
                `;
                i++;
            });
            contents.innerHTML = `
                <div class="card">
                    <table class="stripped responsive-table">
                        <thead>
                            <th>No</th>
                            <th>Nama Negara</th>
                            <th>Tanggal</th>
                            <th>Total Terkonfirmasi</th>
                            <th>Total Death</th>
                            <th>Total Sembuh</th>
                        </thead>
                        <tbody>
                            ${count}
                        </tbody>
                    </table>
                </div>
            `;
        }).catch(err => {
            console.error(err);
        })
}

function loadPage(page) {
    switch (page) {
        case "global":
            getListCovid();
            break;
        case "country":
            getListCountry();
            break;
    }
}
document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.sidenav');
    var instances = M.Sidenav.init(elems);

    document.querySelectorAll(".sidenav a, .topnav a").forEach(elm => {
        elm.addEventListener("click", evt => {
            let sideNav = document.querySelector(".sidenav");
            M.Sidenav.getInstance(sideNav).close();
            page = evt.target.getAttribute("href").substr(1);
            loadPage(page);
        })
    })
    var page = window.location.hash.substr(1);
    if (page === "" || page === "!") page = "country";
    loadPage(page);
});

//Modal detail
document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.modal');
    var modalDetail = M.Modal.init(elems);
});